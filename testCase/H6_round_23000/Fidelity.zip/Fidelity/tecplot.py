import numpy as np
import math as mt

def trans(files, numx, numy, numU, numV):
    data = np.loadtxt(files)
    x = data[:,numx]
    y = data[:,numy]
    value = data[:,numV]
    value2 = data[:,numU]
    r0 = x[0]
    knum = 0
    xnum = 0
    for n in range(len(x)):
        if abs(x[n]-r0)<1e-6:
            knum = knum+1
    size = len(x)
    xnum = size/knum
               
    with open('tecplot.dat', 'w') as f:
        f.write('variables= \"r/D\", \"y/D\", \"Ux/Ub\"\n')
        f.write('zone t=\"Frame 0\" i='+repr(knum)+', j='+repr(int(xnum))+', f=point\n')
        count = 0
        oldValue = []
        used = False        
        for m in range(len(x)-1):
            r0 = x[m]
            if m!=0 :
                for kk in range(len(oldValue)):
                    if abs(r0-oldValue[kk])<1e-6:
                        used = True
                        break
                    elif kk == len(oldValue)-1 :
                        used = False
            if used:
                continue 
            count = 0          
            for n in range(len(x)):
                if abs(x[n]-r0)<1e-6:
                    count = count+1
                    f.write(repr(x[n]/0.04)+' '+repr(y[n]/0.04)+' '+repr(value2[n]/8.9)+'\n')
                    if count == knum:
                        oldValue.append(r0)
                        break                    
    f.close()

trans('postProcessing/cuttingPlate/20000/U_plane.raw', 0, 2, 3, 5)