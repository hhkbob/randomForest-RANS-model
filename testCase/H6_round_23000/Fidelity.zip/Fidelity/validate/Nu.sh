#!/bin/sh

  gnuplot << EOF


  set term post enhanced color solid linewidth 2.0 20
  set encoding utf8
  set termoption dash
  set style increment user
  time = system("foamListTimes -case .. | tail -1")
  name = "SSTCD"
  compare_model = "Standard SST"
# output the Nusselt number
  set terminal png
  set output "current_result/Nu.png"
  set key font "Times Roman, 12"
  set xtics 0, 1, 8 font "Times Roman, 12"
  set ytics 0, 40, 240 font "Times Roman, 12"
  set xlabel "{/Times-Italic r/D}" font "Times Roman, 14" 
  set ylabel "{/Times-Italic Nu / Re^{2/3}}" font "Times Roman, 14" offset 2.4
  set xtics nomirror
  set ytics nomirror
  unset x2tics
  unset y2tics
  set border 3 linewidth 0.25
  plot [0:8][0:240] \
       "exp/expNu.txt" using (\$1):(\$2) title "Cooper et al. 1993" w p pointtype 5 pointsize 0.75, \
       "../postProcessing/surfaces/".time."/wall.xy" \
       using (\$1/0.04):(\$7*-0.04/20.) title name w l linecolor black, \
       "numerical/SST/SSTNu.txt" using (\$1):(\$2) title compare_model w l ls 0

# output the pressure
  set terminal png
  set output "current_result/pressure.png"
  set key font "Times Roman, 12"
  set xtics 0, 0.5, 2 font "Times Roman, 12"
  set ytics 0, 0.2, 1.4 font "Times Roman, 12"
  set xlabel "{/Times-Italic r/D}" font "Times Roman, 14" 
  set ylabel "{/Times-Italic C_{p}}" font "Times Roman, 14" offset 2.4
  set xtics nomirror
  set ytics nomirror
  unset x2tics
  unset y2tics
  set border 3 linewidth 0.25
  plot [0:2][0:1.4] \
       "exp/pressure.txt" using (\$1):(\$2) title "Ahmed et al. 2017" w p pointtype 5 pointsize 0.75, \
       "../postProcessing/surfaces/".time."/wall.xy" \
       using (\$1/0.04):(\$4/(0.5*8.9*8.9)) title name w l linecolor black
      
