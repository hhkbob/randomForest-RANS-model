
lastTime = 20000;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%plot the velocity
loop=[0.5; 1.0; 1.5; 2.0; 2.5; 3.0];
for i=1: length(loop)

  %read the v2f model data
  name=sprintf('../postProcessing/sets/%d/Radial_%1.1f_U.xy', lastTime, loop(i,1));
  CDSST = load( name );

  x=CDSST(:,1)/0.04;
  for k=1:length(x)
   y(k,1) = sqrt(CDSST(k,2)*CDSST(k,2)+CDSST(k,4)*CDSST(k,4))/8.9;
  end
  
  %CDSST fluent    
%   name=sprintf('numerical/fluentCDSST/CDSSTV_%1.1f.csv',loop(i,1));
%   CDSSTf= csvread( name );
%   CDSSTf(1,:)=[];
%   cdy = CDSSTf(:,4)/8.9;
%   cdx = (0.24-CDSSTf(:,2))/0.04;
  
  %RNG fluent
  name=sprintf('numerical/fluentRNG/RNGV_%1.1f.csv',loop(i,1));
  RNGf=csvread(name); RNGf(1,:)=[];
  RNGy = RNGf(:,4)/8.9;
  RNGx = (0.24-RNGf(:,2))/0.04;
  
  %RNG fluent
  name=sprintf('numerical/fluentv2f/v2fV_%1.1f.csv',loop(i,1));
  v2ff=csvread(name); v2ff(1,:)=[];
  v2fy = v2ff(:,4)/8.9;
  v2fx = (0.24-v2ff(:,2))/0.04;

  %read the experimental data
  name_exp=sprintf('exp/expV_%1.1f.txt', loop(i,1));
  exp = load( name_exp );
  ex = exp(:,1);
  ey = exp(:,2);
  
  %read the standard SST model data
  sstname = sprintf('numerical/SST/SSTV_%1.1f.txt',loop(i,1));
  SST = load( sstname );
  sstx = SST(:,1); ssty = SST(:,2);
  
  %read the CDSST data
  CDSSTname = sprintf('numerical/CDSST/CDSSTV_%1.1f.txt', loop(i,1));
  CDSST = load( CDSSTname );
  cdsstx = CDSST(:,1); cdssty = CDSST(:,2);
  
  %plot exp results
  plot(ex, ey,'o', 'MarkerEdgeColor', 'b', 'markerSize', 9); hold on
  %plot standard SST
  plot(sstx, ssty,'-.', 'linewidth', 2.5, 'Color', 'r'); hold on
  %plot CDSST
  plot(cdsstx, cdssty, 'linewidth', 2.5, 'Color', 'k'); hold on
  
  %plot fluent SST numerical results
  plot(x,y,'--', 'linewidth', 2.5, 'Color', 'r'); hold on
  
  %plot fluent CDSST numerical results
  %plot(cdx,cdy,':.', 'linewidth', 2.5, 'Color', 'k'); hold on
  
  %plot fluent RNG data
  plot(RNGx, RNGy, '-.','linewidth', 2.5, 'Color', 'k'); 
  
  %plot fluent v2f data
  plot(v2fx, v2fy, '--.','linewidth', 2.5, 'Color', 'b'); 
  
  xlabel('\it y/D', 'FontSize', 20);
  ylabel('\it U/V_{in}', 'FontSize', 20);
  set(gca,'FontName','times','FontSize',18,'linewidth',2);
  set(gca,'xcolor','k','ycolor','k');
  
  %set the legend
  if( i==1)
    h = legend('Cooper et al. 1993', 'SST openFoam', 'CDSST', 'CDSST-2','RNG fluent', 'v2f fluent',4);
  else
    h = legend('Cooper et al. 1993', 'SST openFoam', 'CDSST','CDSST-2','RNG fluent','v2f fluent');
  end
  axis([0 0.4 0 1.0]);
  set(h, 'FontName', 'times', 'FontSize', 18);
  set(h, 'Box', 'off');
  
  %tight the border
  %ax = gca;
  %outerpos = get(ax, "OuterPosition");
  %ti = get(ax, "TightInset"); 
  %left = outerpos(1) + ti(1);
  %bottom = outerpos(2) + ti(2);
  %ax_width = outerpos(3) - ti(1) - ti(3);
  %ax_height = outerpos(4) - ti(2) - ti(4);
  %set(ax, "Position",[left bottom ax_width ax_height]);
  
  %output
  name = sprintf('current_result/V_H_2%2.0f.jpg', loop(i,1)*10);
  print('-r300', name);
  hold off
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%plot the Nusselt number
%the experimental data
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    expNu = load('exp/expNu.txt');

    %the calculation data
    name=sprintf('../postProcessing/surfaces/%d/surfaceNusseltNum_wall.raw', lastTime);
    [x, y, z, CDSSTNu] = textread(name,'%n%n%n%n', 'headerlines',2); %skip two lines
    %CDSSTf = csvread('numerical/fluentCDSST/CDSSTNu.csv'); CDSSTf(1,:)=[];
    RNGf = csvread('numerical/fluentRNG/RNGNu.csv'); RNGf(1,:)=[];
    v2ff = csvread('numerical/fluentv2f/v2fNu.csv'); v2ff(1,:)=[];

    %plot the data
    plot(expNu(:,1),expNu(:,2), 'o', 'MarkerEdgeColor', 'b', 'markerSize', 9); hold on
    plot(x/0.04,CDSSTNu, '--', 'linewidth', 2.5, 'Color', 'r'); hold on
    %plot(CDSSTf(:,3)/0.04,CDSSTf(:,4), ':.', 'linewidth', 2.5, 'Color', 'k'); hold on
    plot(RNGf(:,3)/0.04,RNGf(:,4), '-.','linewidth', 2.5, 'Color', 'k');  hold on
    plot(v2ff(:,3)/0.04,v2ff(:,4), '--.','linewidth', 2.5, 'Color', 'b');
    
    %set the axis
    axis([0 8 0 180]);
    xlabel('\it r/D', 'FontSize', 20);
    ylabel('\it Nu', 'FontSize', 20);
    set(gca,'FontName','times','FontSize',18,'linewidth',2);
    set(gca,'xcolor','k','ycolor','k');
    
    h = legend('Baughn et al. 1989', 'CDSST', 'RNG fluent', 'v2f fluent');
    set(h, 'FontName', 'times', 'FontSize', 18);
    set(h, 'Box', 'off');
    
    name = sprintf('current_result/Nu.jpg');
    print('-r300', name); 
    hold off  
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%plot the fluctuation
loop=[0.5;1.0;1.5;2.0;3.0];
for i=1: 5
  % the numerical results
  
  %read the v2f model data
  name=sprintf('../postProcessing/sets/%d/Radial_%1.1f_k.xy', lastTime, loop(i,1));
  CDSSTk = load( name );
  
  x=CDSSTk(:,1)/0.04; y=x;
  for k=1:length(x)
   y(k,1) = sqrt(CDSSTk(k,3)*2.0/3.0)/8.9;
  end
  
%  name=sprintf('numerical/fluentCDSST/CDSSTk_%1.1f.csv', loop(i,1));
%  CDSSTf = csvread( name ); CDSSTf(1,:)=[];
  
  name=sprintf('numerical/fluentRNG/RNGk_%1.1f.csv', loop(i,1));
  RNGf = csvread( name); RNGf(1,:)=[];
  
  name=sprintf('numerical/fluentv2f/v2fk_%1.1f.csv', loop(i,1));
  v2ff = csvread( name); v2ff(1,:)=[];
  
  % delete the first row
  %v2f(1,:)=[];

  %read the experimental data
  name_exp=sprintf('exp/expU_%1.1f.txt', loop(i,1));
  expk = load( name_exp ); 
  ex = expk(:,1);
  ey = expk(:,2);
  
  %read the standard SST model data
  sstname = sprintf('numerical/SST/SSTU_%1.1f.txt',loop(i,1));
  SSTk = load( sstname );
  sstx = SSTk(:,1); ssty = SSTk(:,2);
  
  %read the CDSST data
  CDSSTname = sprintf('numerical/CDSST/CDSSTU_%1.1f.txt', loop(i,1));
  CDSSTk = load( CDSSTname );
  cdsstx = CDSSTk(:,1); cdssty = CDSSTk(:,2);
  
  %plot exp results
  plot(ex, ey,'o', 'MarkerEdgeColor', 'b', 'markerSize', 9); hold on
  %plot standard SST
  plot(sstx, ssty,'-.', 'linewidth', 2.5, 'Color', 'b'); hold on
  %plot CDSST
  plot(cdsstx, cdssty, 'linewidth', 2.5, 'Color', 'k'); hold on
  
  %plot v2f numerical results
  plot(x(:,1),y(:,1),'--', 'linewidth', 2.5, 'Color', 'r'); hold on
  %plot((0.24-CDSSTf(:,2))/0.04,sqrt(CDSSTf(:,4)*2/3)/8.9,':.', 'linewidth', 2.5, 'Color', 'k'); hold on
  plot((0.24-RNGf(:,2))/0.04,sqrt(RNGf(:,4)*2/3)/8.9,'-.','linewidth', 2.5, 'Color', 'k'); 
  plot((0.24-v2ff(:,2))/0.04,sqrt(v2ff(:,4)*2/3)/8.9,'--.','linewidth', 2.5, 'Color', 'b');
  
  xlabel('\it y/D', 'FontSize', 20);
  ylabel('\it u/V_{in}', 'FontSize', 20);
  set(gca,'FontName','times','FontSize',18,'linewidth',2);
  set(gca,'xcolor','k','ycolor','k');
  
  %set the legend
  axis([0 0.4 0 0.25]);
  h = legend('Cooper et al. 1993', 'Standard SST', 'CDSST', 'CDSST-2','RNG fluent', 'v2f fluent');
  set(h, 'FontName', 'times', 'FontSize', 18);
  set(h, 'Box', 'off');
  
  %tight the border
  %ax = gca;
  %outerpos = get(ax, "OuterPosition");
  %ti = get(ax, "TightInset"); 
  %left = outerpos(1) + ti(1);
  %bottom = outerpos(2) + ti(2);
  %ax_width = outerpos(3) - ti(1) - ti(3);
  %ax_height = outerpos(4) - ti(2) - ti(4);
  %set(ax, "Position",[left bottom ax_width ax_height]);
  
  %output
  name = sprintf('current_result/U_%2.0f.jpg', loop(i,1)*10);
  print('-r300', name);
  hold off
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%























